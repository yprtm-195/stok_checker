import sqlite3
import datetime
from typing import Optional

from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

HISTORY_DB_FILE = "datastok.db"

@app.get("/api/stok/{kode_toko}")
def get_stok(
    kode_toko: str,
    tanggal: Optional[str] = Query(None, description="Tanggal spesifik (format: DD-MM-YYYY)"),
    start_date: Optional[str] = Query(None, description="Tanggal mulai range (format: DD-MM-YYYY)"),
    end_date: Optional[str] = Query(None, description="Tanggal akhir range (format: DD-MM-YYYY)"),
):
    try:
        conn = sqlite3.connect(HISTORY_DB_FILE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        # Base query aliases columns to match the old CSV output
        base_query = "SELECT product_id AS kodeproduk, product_name AS namaproduk, stock FROM stock_history WHERE store_code = ?"
        params = [kode_toko]

        # Date filtering logic
        if start_date and end_date:
            # Range Tanggal
            start_dt = datetime.datetime.strptime(start_date, "%d-%m-%Y").strftime("%Y-%m-%d")
            end_dt = datetime.datetime.strptime(end_date, "%d-%m-%Y").strftime("%Y-%m-%d")
            base_query += " AND DATE(check_timestamp) BETWEEN ? AND ?"
            params.extend([start_dt, end_dt])
        else:
            # Tanggal spesifik atau hari ini
            target_date_str = ""
            if tanggal:
                target_date_str = datetime.datetime.strptime(tanggal, "%d-%m-%Y").strftime("%Y-%m-%d")
            else: # Tanggal berjalan (hari ini)
                target_date_str = datetime.datetime.now().strftime("%Y-%m-%d")
            
            base_query += " AND DATE(check_timestamp) = ?"
            params.append(target_date_str)

        cursor.execute(base_query, tuple(params))
        results = cursor.fetchall()
        
        # Convert rows to list of dicts
        all_data = [dict(row) for row in results]

        if not all_data:
            return {"error": "Tidak ada data ditemukan pada tanggal tersebut"}
        
        return all_data

    except ValueError:
        return {"error": "Format tanggal salah. Gunakan DD-MM-YYYY"}
    except sqlite3.Error as e:
        return {"error": f"Database error: {e}"}
    finally:
        if 'conn' in locals() and conn:
            conn.close()


@app.get("/")
def read_root():
    return {"Hello": "World"}