# Stok Checker Server

Versi ini adalah adaptasi dari aplikasi Stok Checker GUI menjadi sebuah layanan server _headless_ (tanpa tampilan) yang berjalan di background. Tujuannya adalah untuk melakukan pengecekan stok secara otomatis dan menyediakan hasilnya melalui sebuah Web API.

## Struktur File

-   `server_main.py`: Titik masuk utama aplikasi. Bertugas menjalankan scheduler dan server API.
-   `core_logic.py`: "Otak" dari aplikasi. Berisi semua logika untuk mengambil data stok dari Alfagift, mengelola database, dan memproses data.
-   `api_setup.py`: Mendefinisikan semua _endpoint_ (URL) untuk Web API menggunakan FastAPI.
-   `requirements.txt`: Daftar semua library Python yang dibutuhkan oleh aplikasi.
-   `produk_mapping.json`: File konfigurasi untuk memetakan produk.
-   `listtoko.csv`: File konfigurasi yang berisi daftar semua toko.
-   `data.db`: Database SQLite untuk menyimpan data produk dan toko. Dibuat otomatis saat pertama kali dijalankan.
-   `datastok.db`: Database SQLite untuk menyimpan riwayat hasil pengecekan stok.

## Cara Kerja

Aplikasi ini bekerja dengan menjalankan dua proses utama secara bersamaan (menggunakan _multi-threading_):

1.  **Scheduler (Penjadwal Otomatis)**:
    -   Saat `server_main.py` dijalankan, sebuah penjadwal akan aktif.
    -   Setiap satu jam, penjadwal ini akan memeriksa apakah tanggal (berdasarkan zona waktu WITA/Makassar) sudah berganti.
    -   Jika hari telah berganti, penjadwal akan:
        1.  Mengambil daftar semua toko dari `core_logic`.
        2.  Memeriksa riwayat di `datastok.db` untuk melihat toko mana saja yang sudah dicek hari itu.
        3.  Membuat sebuah antrian (queue) yang berisi toko-toko yang **belum** dicek.
        4.  Mulai memproses antrian satu per satu, memanggil fungsi `run_stock_check_process` untuk setiap toko.
    -   Proses ini akan terus berjalan di background.

2.  **API Server (Penyedia Data)**:
    -   Bersamaan dengan scheduler, sebuah server web menggunakan FastAPI juga dijalankan.
    -   Server ini akan aktif di port `8000` dan bisa diakses dari jaringan lokal.
    -   Tugasnya adalah menyediakan data riwayat stok yang tersimpan di `datastok.db` jika ada yang memintanya melalui URL API yang sudah ditentukan di `api_setup.py`.

## Instalasi & Menjalankan

1.  Buka terminal atau Command Prompt.
2.  Masuk ke direktori aplikasi:
    ```bash
    cd path\to\stok_checker_server
    ```
3.  Install semua library yang dibutuhkan:
    ```bash
    pip install -r requirements.txt
    ```
4.  Jalankan server:
    ```bash
    python server_main.py
    ```
5.  Server akan berjalan dan menampilkan log aktivitasnya di terminal. Untuk menghentikan server, tekan `Ctrl+C`.

## Mengakses API

Setelah server berjalan, Anda bisa mengambil data stok melalui browser atau tool API lainnya.

-   **Endpoint Utama**: `GET /api/stok/{kode_toko}`
-   **Alamat**: `http://<IP_SERVER>:8000/api/stok/{kode_toko}`
    -   Ganti `<IP_SERVER>` dengan alamat IP mesin tempat server berjalan (misal: `127.0.0.1` jika di mesin yang sama, atau `192.168.1.10` jika di jaringan lokal).
    -   Ganti `{kode_toko}` dengan kode toko yang valid.

**Parameter Tambahan (Query)**:

-   `tanggal`: Untuk mendapatkan data pada tanggal spesifik.
    -   Contoh: `http://127.0.0.1:8000/api/stok/1Y5A?tanggal=04-10-2025`
-   `start_date` & `end_date`: Untuk mendapatkan data dalam rentang tanggal.
    -   Contoh: `http://127.0.0.1:8000/api/stok/1Y5A?start_date=01-10-2025&end_date=04-10-2025`

Jika tidak ada parameter tanggal yang diberikan, API akan otomatis mengembalikan data untuk hari ini.
