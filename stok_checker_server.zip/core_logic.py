import requests
import sqlite3
import json
import base64
import os
import time
import random
import csv
from datetime import datetime
from collections import defaultdict

DB_FILE = "data.db"
HISTORY_DB_FILE = "datastok.db"

def initialize_database():
    if os.path.exists(DB_FILE):
        return
    print("Database tidak ditemukan, membuat dan menginisialisasi database baru...")
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    try:
        cursor.execute('''
            CREATE TABLE products (
                id TEXT PRIMARY KEY,
                product_name TEXT NOT NULL,
                is_core BOOLEAN NOT NULL
            )
        ''')
        cursor.execute('''
            CREATE TABLE stores (
                storecode TEXT PRIMARY KEY,
                storename TEXT,
                storebranch TEXT,
                flagroute TEXT
            )
        ''')
        with open("produk_mapping.json", 'r', encoding='utf-8') as f:
            products = json.load(f)
            for p in products:
                cursor.execute("INSERT INTO products (id, product_name, is_core) VALUES (?, ?, ?)",
                               (p.get('id'), p.get('product_name'), p.get('is_core', False)))
        print("Migrasi data produk dari JSON berhasil.")
        processed_storecodes = set()
        with open("listtoko.csv", 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                store_code = row.get('storecode')
                if store_code and store_code not in processed_storecodes:
                    cursor.execute("INSERT INTO stores (storecode, storename, storebranch, flagroute) VALUES (?, ?, ?, ?)",
                                   (store_code, row.get('storename'), row.get('storebranch'), row.get('flagroute')))
                    processed_storecodes.add(store_code)
        print(f"Migrasi data toko dari CSV berhasil. {len(processed_storecodes)} toko unik ditambahkan.")
        conn.commit()
    except Exception as e:
        print(f"Gagal saat inisialisasi database: {e}")
        conn.rollback()
    finally:
        conn.close()
        print("Inisialisasi database selesai.")

def load_product_mapping():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM products ORDER BY product_name")
    products = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return products

def load_store_list():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM stores ORDER BY storename")
    stores = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return stores

def delete_product(product_id):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM products WHERE id = ?", (product_id,))
        conn.commit()
    except Exception as e:
        print(f"Gagal menghapus produk: {e}")
    finally:
        if conn:
            conn.close()

def delete_store(store_code):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM stores WHERE storecode = ?", (store_code,))
        conn.commit()
    except Exception as e:
        print(f"Gagal menghapus toko: {e}")
    finally:
        if conn:
            conn.close()

def update_product(product_id, new_name, new_is_core):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("UPDATE products SET product_name = ?, is_core = ? WHERE id = ?",
                       (new_name, new_is_core, product_id))
        conn.commit()
    except Exception as e:
        print(f"Gagal mengupdate produk: {e}")
    finally:
        if conn:
            conn.close()

def update_store(original_storecode, new_data):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""UPDATE stores SET 
                          storecode = ?, 
                          storename = ?, 
                          storebranch = ?, 
                          flagroute = ? 
                       WHERE storecode = ?""",
                       (new_data['storecode'], new_data['storename'],
                        new_data['storebranch'], new_data['flagroute'], original_storecode))
        conn.commit()
    except Exception as e:
        print(f"Gagal mengupdate toko: {e}")
    finally:
        if conn:
            conn.close()

def add_product(product_id, name, is_core):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO products (id, product_name, is_core) VALUES (?, ?, ?)",
                       (product_id, name, is_core))
        conn.commit()
        return True, None
    except sqlite3.IntegrityError:
        return False, f"Produk dengan ID '{product_id}' sudah ada."
    except Exception as e:
        print(f"Gagal menambah produk: {e}")
        return False, str(e)
    finally:
        if conn:
            conn.close()

def add_store(data):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""INSERT INTO stores (storecode, storename, storebranch, flagroute) 
                          VALUES (?, ?, ?, ?)""",
                       (data['storecode'], data['storename'],
                        data['storebranch'], data['flagroute']))
        conn.commit()
        return True, None
    except sqlite3.IntegrityError:
        return False, f"Toko dengan kode '{data['storecode']}' sudah ada."
    except Exception as e:
        print(f"Gagal menambah toko: {e}")
        return False, str(e)
    finally:
        if conn:
            conn.close()

def get_store_details(store_code):
    details = {}
    try:
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT storename, storebranch, flagroute FROM stores WHERE storecode = ?", (store_code,))
        row = cursor.fetchone()
        if row:
            details = dict(row)
    except Exception as e:
        print(f"Gagal mengambil detail toko: {e}")
    finally:
        if 'conn' in locals() and conn:
            conn.close()
    return details

def load_stock_history(filters={}):
    records = []
    conn = None
    try:
        conn = sqlite3.connect(HISTORY_DB_FILE)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        query = "SELECT id, check_timestamp, store_code, product_id, product_name, stock FROM stock_history"
        where_clauses = []
        params = []
        if filters.get("start_date"):
            where_clauses.append("DATE(check_timestamp) >= ?")
            params.append(filters["start_date"])
        if filters.get("end_date"):
            where_clauses.append("DATE(check_timestamp) <= ?")
            params.append(filters["end_date"])
        if filters.get("store_code"):
            where_clauses.append("store_code LIKE ?")
            params.append(f"%{filters['store_code']}%")
        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)
        query += " ORDER BY check_timestamp DESC"
        cursor.execute(query, params)
        records = [dict(row) for row in cursor.fetchall()]
    except Exception as e:
        print(f"[ERROR] Gagal memuat history stok: {e}")
    finally:
        if conn:
            conn.close()
    return records

def get_completed_stores_for_today():
    completed_stores = set()
    conn = None
    try:
        if not os.path.exists(HISTORY_DB_FILE):
            return completed_stores
        conn = sqlite3.connect(HISTORY_DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='stock_history'")
        if cursor.fetchone() is None:
            return completed_stores
        today_date = datetime.now().strftime('%Y-%m-%d')
        cursor.execute("SELECT DISTINCT store_code FROM stock_history WHERE DATE(check_timestamp) = ?", (today_date,))
        rows = cursor.fetchall()
        completed_stores = {row[0] for row in rows}
        print(f"[INFO] Ditemukan {len(completed_stores)} toko yang sudah selesai hari ini.")
    except Exception as e:
        print(f"[ERROR] Gagal mengambil data toko yang sudah selesai: {e}")
    finally:
        if conn:
            conn.close()
    return completed_stores



def process_one_attempt(store_code, store_details, product_mapping):
    analysis_result = {
        "is_core_complete": False,
        "availability_ratio": -1.0,
        "found_products_data": []
    }
    keywords = {p.get("product_name", "").split(' ')[0].lower() for p in product_mapping if p.get("product_name")}
    headers = {
        'accept': 'application/json', 'accept-language': 'id', 'devicemodel': 'chrome', 'devicetype': 'Web',
        'fingerprint': 'VWr1+Vq4VBSKZVTJFRTATTIM3rw8jbI+7vtsTGZfDe1SfCMN+bixVE4ZxTu/YC75',
        'latitude': '0', 'longitude': '0', 'origin': 'https://alfagift.id', 'priority': 'u=1, i', 'referer': 'https://alfagift.id/',
        'token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI2MmZlMGY3MzFlODYzNzYzNGY2Mzg5YzMiLCJzdWIiOiJ5b2hhbmRpLnByYXRhbWFAZ21haWwuY29tIiwiaXNzIjoid2ViY29tbWVyY2V8c2Vzc2lvbnxXRUIiLCJleHAiOjE3NjE3NDIwMzUsImlhdCI6MTc1OTE1MDAzNX0.-Vb1hc7jBs6xMdgWDbhaDP7U7kTwQ60XrzXxUeoOgwE',
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
    }
    fccode_data = {"seller_id": "1", "fc_code": store_details.get("storebranch", "")}
    headers['fccode'] = base64.b64encode(json.dumps(fccode_data).encode('utf-8')).decode('utf-8')
    storecode_data = {"store_code": store_code, "delivery": True, "depo_id": "", "sapa": True, "store_method": 1, "distance": 1065.0, "maxDistance": None, "flagRoute": store_details.get("flagroute", "")}
    headers['storecode'] = base64.b64encode(json.dumps(storecode_data, separators=(',', ':')).encode('utf-8')).decode('utf-8')
    all_api_products = []
    for keyword in keywords:
        start, limit = 0, 60
        while True:
            url = f'https://webcommerce-gw.alfagift.id/v2/products/searches?keyword={keyword}&start={start}&limit={limit}'
            response = requests.get(url, headers=headers)
            response.raise_for_status()
            data = response.json()
            products_on_page = data.get("products", [])
            if not products_on_page: break
            all_api_products.extend(products_on_page)
            start += limit
            if len(all_api_products) >= data.get('totalData', 0): break
    mapping_lookup = defaultdict(list)
    for p in product_mapping: mapping_lookup[p["product_name"]].append(p)
    core_products_in_map = {p["id"] for p in product_mapping if p.get('is_core')}
    total_core_products = len(core_products_in_map)
    core_products_missing = set(core_products_in_map)
    core_items_in_stock_count = 0
    found_products_data = []
    for item in all_api_products:
        product_name = item.get('productName')
        if product_name in mapping_lookup:
            stock = item.get('stock', 0)
            for mapped_product in mapping_lookup[product_name]:
                custom_id = mapped_product.get('id', 'N/A')
                is_core = mapped_product.get('is_core', False)
                product_data = {"custom_id": custom_id, "product_name": product_name, "stock": stock}
                if product_data not in found_products_data:
                    found_products_data.append(product_data)
                if is_core and stock > 0:
                    core_items_in_stock_count += 1
                    core_products_missing.discard(custom_id)
    analysis_result["found_products_data"] = found_products_data
    if total_core_products > 0:
        ratio = (core_items_in_stock_count / total_core_products) * 100
        analysis_result["availability_ratio"] = ratio
    else:
        analysis_result["availability_ratio"] = 100.0
    analysis_result["is_core_complete"] = not core_products_in_map or not core_products_missing
    return analysis_result

def log_results_to_db(store_code, found_products_data):
    conn = None
    try:
        conn = sqlite3.connect(HISTORY_DB_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stock_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                check_timestamp DATETIME NOT NULL,
                store_code TEXT NOT NULL,
                product_id TEXT NOT NULL,
                product_name TEXT,
                stock INTEGER NOT NULL
            )
        ''')
        today_date = datetime.now().strftime('%Y-%m-%d')
        cursor.execute("DELETE FROM stock_history WHERE store_code = ? AND DATE(check_timestamp) = ?", (store_code, today_date))
        timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        records_to_insert = []
        for product in found_products_data:
            record = (
                timestamp,
                store_code,
                product.get('custom_id'),
                product.get('product_name'),
                product.get('stock')
            )
            records_to_insert.append(record)
        if records_to_insert:
            cursor.executemany(
                "INSERT INTO stock_history (check_timestamp, store_code, product_id, product_name, stock) VALUES (?, ?, ?, ?, ?)",
                records_to_insert
            )
            conn.commit()
            print(f"[INFO] Berhasil mencatat {len(records_to_insert)} record baru untuk toko {store_code} ke {HISTORY_DB_FILE}")
    except Exception as e:
        print(f"[ERROR] Gagal mencatat history ke database: {e}")
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()

def run_stock_check_process(store_code, store_details, start_attempt_callback, update_callback, final_callback):
    try:
        product_mapping = load_product_mapping()
    except (FileNotFoundError, IOError) as e:
        final_callback(False, -1, error=str(e))
        return

    max_attempts = 2
    best_ratio = -1.0
    best_data_cache = None
    best_attempt_is_complete = False
    last_error = None

    for attempt in range(1, max_attempts + 1):
        start_attempt_callback(attempt)
        try:
            result = process_one_attempt(store_code.strip().upper(), store_details, product_mapping)
            update_callback(attempt, result['is_core_complete'], result['availability_ratio'])
            last_error = None
            if result["availability_ratio"] >= best_ratio:
                best_ratio = result["availability_ratio"]
                best_data_cache = result["found_products_data"]
                best_attempt_is_complete = result["is_core_complete"]
            if result["is_core_complete"]:
                best_attempt_is_complete = True
                break
            if attempt < max_attempts:
                delay_time = random.uniform(2, 5)
                print(f"[DEBUG] Sleeping for {delay_time:.2f} seconds before next attempt.")
                time.sleep(delay_time)
        except requests.exceptions.RequestException as e:
            last_error = str(e)
            update_callback(attempt, False, -1, error=last_error)
        except Exception as e:
            last_error = str(e)
            update_callback(attempt, False, -1, error=last_error)
            break

    if best_data_cache is not None:
        log_results_to_db(store_code.strip().upper(), best_data_cache)
    
    final_callback(best_attempt_is_complete, best_ratio, error=last_error)