
import threading
import time
import uvicorn
from datetime import datetime
from zoneinfo import ZoneInfo

from api_setup import app as fastapi_app
from core_logic import (
    load_store_list,
    get_completed_stores_for_today,
    get_store_details,
    run_stock_check_process,
    initialize_database
)

# --- Konfigurasi ---
WITA_TZ = ZoneInfo("Asia/Makassar")
CHECK_INTERVAL_HOURS = 1  # Cek setiap 1 jam apakah hari sudah berganti

# --- State Global ---
store_queue = []
last_run_date = None
is_processing = False

def console_logger(level, message):
    """Fungsi logging sederhana ke konsol."""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"[{timestamp}] [{level.upper()}] {message}")

def start_attempt_callback(store_code, attempt):
    console_logger("info", f"Toko {store_code}: Memulai percobaan ke-{attempt}...")

def update_callback(store_code, attempt, is_complete, ratio, error=None):
    status = f"Ratio: {ratio:.2f}%"
    if error:
        status = f"Error: {error}"
    console_logger("info", f"Toko {store_code}: Percobaan ke-{attempt} selesai. Status: {status}")

def final_callback(store_code, is_complete, ratio, error=None):
    global is_processing
    status = f"Ratio: {ratio:.2f}%"
    if error:
        status = f"Error: {error}"
    console_logger("success", f"Toko {store_code}: Proses selesai. Hasil akhir: {status}")
    
    # Lanjutkan ke toko berikutnya jika ada
    if store_queue:
        process_next_in_queue()
    else:
        console_logger("info", "Semua toko dalam antrian telah selesai diproses.")
        is_processing = False

def process_next_in_queue():
    """Mengambil dan memproses toko berikutnya dari antrian."""
    if not store_queue:
        console_logger("info", "Antrian kosong, tidak ada yang diproses.")
        return

    store_code = store_queue.pop(0)
    console_logger("info", f"Memulai proses untuk toko: {store_code}")
    
    details = get_store_details(store_code)
    
    # Bungkus proses dalam thread agar tidak memblokir scheduler
    thread = threading.Thread(
        target=run_stock_check_process,
        args=(
            store_code,
            details,
            lambda attempt: start_attempt_callback(store_code, attempt),
            lambda attempt, complete, ratio, error=None: update_callback(store_code, attempt, complete, ratio, error),
            lambda is_complete, ratio, error=None: final_callback(store_code, is_complete, ratio, error)
        )
    )
    thread.daemon = True
    thread.start()

def daily_check_scheduler():
    """Penjadwal yang memeriksa apakah proses harian perlu dijalankan."""
    global last_run_date, store_queue, is_processing
    
    while True:
        wita_now = datetime.now(WITA_TZ).date()
        
        if wita_now != last_run_date and not is_processing:
            console_logger("info", "Hari baru terdeteksi (WITA). Memulai proses pengecekan harian.")
            last_run_date = wita_now
            is_processing = True
            
            try:
                all_stores = load_store_list()
                completed_today = get_completed_stores_for_today()
                
                store_queue = [s['storecode'] for s in all_stores if s['storecode'] not in completed_today]
                
                if not store_queue:
                    console_logger("info", "Semua toko sudah dicek untuk hari ini.")
                    is_processing = False
                else:
                    console_logger("info", f"Menambahkan {len(store_queue)} toko ke dalam antrian.")
                    process_next_in_queue()

            except Exception as e:
                console_logger("error", f"Gagal memulai proses harian: {e}")
                is_processing = False

        else:
            if is_processing:
                console_logger("debug", "Proses harian sedang berjalan, scheduler menunggu.")
            else:
                console_logger("debug", "Scheduler check: Belum ada hari baru atau proses sudah selesai.")

        # Tunggu sebelum cek berikutnya
        time.sleep(CHECK_INTERVAL_HOURS * 3600)

def run_api_server():
    """Menjalankan server FastAPI di thread terpisah."""
    console_logger("info", "Mempersiapkan untuk menjalankan server API di http://0.0.0.0:8000")
    uvicorn.run(fastapi_app, host="0.0.0.0", port=8000)

if __name__ == "__main__":
    console_logger("info", "Aplikasi Server Stok Checker dimulai.")
    
    # 1. Inisialisasi database jika belum ada
    console_logger("info", "Menginisialisasi database...")
    initialize_database()
    
    # 2. Jalankan API server di background
    api_thread = threading.Thread(target=run_api_server, daemon=True)
    api_thread.start()
    console_logger("info", "Thread server API telah dimulai.")
    
    # 3. Jalankan scheduler di thread utama
    console_logger("info", "Memulai scheduler pengecekan harian.")
    daily_check_scheduler()
